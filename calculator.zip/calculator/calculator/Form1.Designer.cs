﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button10 = new Button();
            textBox2 = new TextBox();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveBorder;
            button1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(248, 388);
            button1.Name = "button1";
            button1.Size = new Size(90, 50);
            button1.TabIndex = 0;
            button1.Text = ".";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button8_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveBorder;
            button2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(135, 384);
            button2.Name = "button2";
            button2.Size = new Size(90, 50);
            button2.TabIndex = 1;
            button2.Text = "0";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button8_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveBorder;
            button3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(12, 384);
            button3.Name = "button3";
            button3.Size = new Size(90, 50);
            button3.TabIndex = 2;
            button3.Text = "AC";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(255, 128, 0);
            button4.Font = new Font("Segoe UI Black", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(361, 388);
            button4.Name = "button4";
            button4.Size = new Size(90, 50);
            button4.TabIndex = 3;
            button4.Text = "=";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(255, 128, 0);
            button5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(361, 332);
            button5.Name = "button5";
            button5.Size = new Size(90, 50);
            button5.TabIndex = 4;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ActiveBorder;
            button6.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(248, 332);
            button6.Name = "button6";
            button6.Size = new Size(90, 50);
            button6.TabIndex = 5;
            button6.Text = "3";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button8_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ActiveBorder;
            button7.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.Location = new Point(135, 328);
            button7.Name = "button7";
            button7.Size = new Size(90, 50);
            button7.TabIndex = 6;
            button7.Text = "2";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button8_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ActiveBorder;
            button8.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.Location = new Point(12, 332);
            button8.Name = "button8";
            button8.Size = new Size(90, 50);
            button8.TabIndex = 7;
            button8.Text = "1";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(255, 128, 0);
            button9.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.Location = new Point(361, 276);
            button9.Name = "button9";
            button9.Size = new Size(90, 50);
            button9.TabIndex = 8;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button5_Click;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ActiveBorder;
            button11.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button11.Location = new Point(135, 272);
            button11.Name = "button11";
            button11.Size = new Size(90, 50);
            button11.TabIndex = 10;
            button11.Text = "5";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button8_Click;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.ActiveBorder;
            button12.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button12.Location = new Point(12, 276);
            button12.Name = "button12";
            button12.Size = new Size(90, 50);
            button12.TabIndex = 11;
            button12.Text = "4";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button8_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.FromArgb(255, 128, 0);
            button13.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button13.Location = new Point(361, 220);
            button13.Name = "button13";
            button13.Size = new Size(90, 50);
            button13.TabIndex = 12;
            button13.Text = "*";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button5_Click;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.ActiveBorder;
            button14.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button14.Location = new Point(248, 220);
            button14.Name = "button14";
            button14.Size = new Size(90, 50);
            button14.TabIndex = 13;
            button14.Text = "9";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button8_Click;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ActiveBorder;
            button15.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button15.Location = new Point(135, 220);
            button15.Name = "button15";
            button15.Size = new Size(90, 50);
            button15.TabIndex = 14;
            button15.Text = "8";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button8_Click;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.ActiveBorder;
            button16.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button16.Location = new Point(12, 220);
            button16.Name = "button16";
            button16.Size = new Size(90, 50);
            button16.TabIndex = 15;
            button16.Text = "7";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button8_Click;
            // 
            // button17
            // 
            button17.BackColor = Color.FromArgb(255, 128, 0);
            button17.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button17.Location = new Point(361, 164);
            button17.Name = "button17";
            button17.Size = new Size(90, 50);
            button17.TabIndex = 16;
            button17.Text = "/";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button5_Click;
            // 
            // button18
            // 
            button18.BackColor = SystemColors.ActiveBorder;
            button18.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button18.Location = new Point(248, 164);
            button18.Name = "button18";
            button18.Size = new Size(90, 50);
            button18.TabIndex = 17;
            button18.Text = ")";
            button18.UseVisualStyleBackColor = false;
            button18.Click += button5_Click;
            // 
            // button19
            // 
            button19.BackColor = SystemColors.ActiveBorder;
            button19.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button19.Location = new Point(135, 164);
            button19.Name = "button19";
            button19.Size = new Size(90, 50);
            button19.TabIndex = 18;
            button19.Text = "(";
            button19.UseVisualStyleBackColor = false;
            button19.Click += button5_Click;
            // 
            // button20
            // 
            button20.BackColor = SystemColors.ActiveBorder;
            button20.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button20.Location = new Point(12, 164);
            button20.Name = "button20";
            button20.Size = new Size(90, 50);
            button20.TabIndex = 19;
            button20.Text = "C";
            button20.UseVisualStyleBackColor = false;
            button20.Click += button20_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ActiveBorder;
            button10.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.Location = new Point(248, 276);
            button10.Name = "button10";
            button10.Size = new Size(90, 50);
            button10.TabIndex = 9;
            button10.Text = "6";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button8_Click;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(151, 12);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(443, 34);
            textBox2.TabIndex = 23;
            textBox2.Text = "0";
            textBox2.TextAlign = HorizontalAlignment.Right;
            // 
            // button21
            // 
            button21.BackColor = SystemColors.ActiveBorder;
            button21.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button21.ForeColor = SystemColors.ActiveCaptionText;
            button21.Location = new Point(12, 108);
            button21.Name = "button21";
            button21.Size = new Size(90, 50);
            button21.TabIndex = 24;
            button21.Text = "√";
            button21.UseVisualStyleBackColor = false;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.BackColor = SystemColors.ActiveBorder;
            button22.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button22.ForeColor = SystemColors.ControlText;
            button22.Location = new Point(484, 164);
            button22.Name = "button22";
            button22.Size = new Size(70, 50);
            button22.TabIndex = 25;
            button22.Text = "A";
            button22.UseVisualStyleBackColor = false;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.BackColor = SystemColors.ActiveBorder;
            button23.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button23.Location = new Point(484, 226);
            button23.Name = "button23";
            button23.Size = new Size(70, 50);
            button23.TabIndex = 26;
            button23.Text = "B";
            button23.UseVisualStyleBackColor = false;
            button23.Click += button22_Click;
            // 
            // button24
            // 
            button24.BackColor = SystemColors.ActiveBorder;
            button24.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button24.Location = new Point(484, 282);
            button24.Name = "button24";
            button24.Size = new Size(70, 50);
            button24.TabIndex = 27;
            button24.Text = "C";
            button24.UseVisualStyleBackColor = false;
            button24.Click += button22_Click;
            // 
            // button25
            // 
            button25.BackColor = SystemColors.ActiveBorder;
            button25.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button25.Location = new Point(484, 338);
            button25.Name = "button25";
            button25.Size = new Size(70, 50);
            button25.TabIndex = 28;
            button25.Text = "D";
            button25.UseVisualStyleBackColor = false;
            button25.Click += button22_Click;
            // 
            // button26
            // 
            button26.BackColor = SystemColors.ActiveBorder;
            button26.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button26.Location = new Point(484, 394);
            button26.Name = "button26";
            button26.Size = new Size(70, 50);
            button26.TabIndex = 29;
            button26.Text = "E";
            button26.UseVisualStyleBackColor = false;
            button26.Click += button22_Click;
            // 
            // button27
            // 
            button27.BackColor = SystemColors.ActiveBorder;
            button27.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button27.Location = new Point(584, 164);
            button27.Name = "button27";
            button27.Size = new Size(70, 50);
            button27.TabIndex = 30;
            button27.Text = "F";
            button27.UseVisualStyleBackColor = false;
            button27.Click += button22_Click;
            // 
            // button28
            // 
            button28.BackColor = SystemColors.ActiveBorder;
            button28.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button28.Location = new Point(135, 108);
            button28.Name = "button28";
            button28.Size = new Size(90, 50);
            button28.TabIndex = 31;
            button28.Text = "Dec to Hex";
            button28.UseVisualStyleBackColor = false;
            button28.Click += button28_Click;
            // 
            // button29
            // 
            button29.BackColor = SystemColors.ActiveBorder;
            button29.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button29.Location = new Point(248, 108);
            button29.Name = "button29";
            button29.Size = new Size(90, 50);
            button29.TabIndex = 32;
            button29.Text = "Hex to Dec";
            button29.UseVisualStyleBackColor = false;
            button29.Click += button29_Click;
            // 
            // button30
            // 
            button30.BackColor = SystemColors.ActiveBorder;
            button30.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button30.Location = new Point(361, 108);
            button30.Name = "button30";
            button30.Size = new Size(90, 50);
            button30.TabIndex = 33;
            button30.Text = "Dec to Binary";
            button30.UseVisualStyleBackColor = false;
            button30.Click += button30_Click;
            // 
            // button31
            // 
            button31.BackColor = SystemColors.ActiveBorder;
            button31.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button31.Location = new Point(474, 108);
            button31.Name = "button31";
            button31.Size = new Size(90, 50);
            button31.TabIndex = 34;
            button31.Text = "BInary to Dec";
            button31.UseVisualStyleBackColor = false;
            button31.Click += button31_Click;
            // 
            // button32
            // 
            button32.BackColor = SystemColors.ActiveBorder;
            button32.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button32.Location = new Point(570, 108);
            button32.Name = "button32";
            button32.Size = new Size(90, 50);
            button32.TabIndex = 35;
            button32.Text = "!";
            button32.UseVisualStyleBackColor = false;
            button32.Click += button32_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button32);
            Controls.Add(button31);
            Controls.Add(button30);
            Controls.Add(button29);
            Controls.Add(button28);
            Controls.Add(button27);
            Controls.Add(button26);
            Controls.Add(button25);
            Controls.Add(button24);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(textBox2);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button10;
        private TextBox textBox2;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
    }
}
